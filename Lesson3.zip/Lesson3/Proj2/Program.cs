﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proj2
{
    /*Задание:  а) С клавиатуры вводятся числа, пока не будет введен 0 (каждое число в новой строке).
                   Требуется подсчитать сумму всех нечетных положительных чисел. Сами числа и сумму вывести на экран, используя tryParse;
                б) Добавить обработку исключительных ситуаций на то, что могут быть введены некорректные данные.
                   При возникновении ошибки вывести сообщение. Напишите соответствующую функцию;
    Фамилия:  Орлов
*/
    class Program
    { // не стал изобретать велосипед и взял свой 3-й проект из предыдущего урока
        static void Main(string[] args)
        {
            Console.Title = "Подсчёт суммы всех нечетных положительных чисел";
            Work();
        }
        static public void Work()
        {
            List<int> list = new List<int>();
            int num;
            do
            {
                Console.Clear();
                Console.WriteLine("Для выхода из цикла введите 0");
                num = GetAndCheckINT();
                if (num % 2 != 0 && num > 0) // проверяю на нечётность введённое число
                    list.Add(num);

            }
            while (num != 0);
            PrintSum(list);
        }
        public static int GetAndCheckINT()
        {
            int num = 0;
            while (true)
            {
                Console.Write($"Введите число: ");
                if (Int32.TryParse(Console.ReadLine(), out num))
                    break;
                else
                {
                    Console.Clear();
                    Console.WriteLine($"Введённое значение не число!, попробуйте снова");
                }
            }
            return num;
        }
        static public void PrintSum(List<int> list)
        {
            Console.Clear();

            int sum = 0;
            Console.WriteLine("Введённые положительные нечётные числа: ");
            foreach (int i in list)
            {
                sum += i;
                Console.WriteLine(i);
            }
            Console.WriteLine($"Сумма чисел: {sum}");
            Console.ReadKey(true);
        }
    }
}
