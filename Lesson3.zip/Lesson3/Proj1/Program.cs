﻿using System;

namespace Proj1
{
    /*Задание:  а) Дописать структуру Complex, добавив метод вычитания комплексных чисел.Продемонстрировать работу структуры;
                б) Дописать класс Complex, добавив методы вычитания и произведения чисел.Проверить работу класса;
      Фамилия:  Орлов
    */

    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Комплексные числа";

            Complex complex1 = new Complex(2, 4);
            Complex complex2 = new Complex(3, -2);
            // тест свойств
            complex1.Re = 5;
            complex2.Im = -3;
            // тест методов
            Console.WriteLine($"{complex1} '+' {complex2} = {complex1.Plus(complex2)}");
            Console.WriteLine($"{complex1} '-' {complex2} = {complex1.Minus(complex2)}");
            Console.WriteLine($"{complex1} '*' {complex2} = {complex1.Multi(complex2)}");
            Console.WriteLine("Перегрузка операторов:");
            Console.WriteLine($"{complex1} '+' {complex2} = {complex1 + complex2}");
            Console.WriteLine($"{complex1} '-' {complex2} = {complex1 - complex2}");
            Console.WriteLine($"{complex1} '*' {complex2} = {complex1 * complex2}");
            Console.ReadKey(true);
        }
    }
}
