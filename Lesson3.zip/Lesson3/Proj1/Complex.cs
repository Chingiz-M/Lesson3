﻿
namespace Proj1
{
    struct Complex
    {
        public Complex Plus(Complex x)
        {
            Complex y;
            y.im = im + x.im;
            y.re = re + x.re;
            return y;
        }
        public Complex Minus(Complex x)
        {
            Complex y;
            y.im = im - x.im;
            y.re = re - x.re;
            return y;
        }
        public Complex Multi(Complex x)
        {
            Complex y;
            y.im = re * x.im + im * x.re;
            y.re = re * x.re - im * x.im;
            return y;
        }
        public Complex(double _re, double _im)
        {
            im = _im;
            re = _re;
        }
        // переопределил операторы, а то методы некрасиво мне показалось, но нужно по заданию
        public static Complex operator +(Complex x, Complex y) => new Complex(x.Re + y.Re, x.Im + y.Im);
        public static Complex operator -(Complex x, Complex y) => new Complex(x.Re - y.Re, x.Im - y.Im);
        public static Complex operator *(Complex x, Complex y) => new Complex( x.Re * y.Re - x.Im * y.Im, x.Re * y.Im + x.Im * y.Re);
        public double Im { get { return im; } set { im = value;}        }
        public double Re { get { return re; } set { re = value;} }

        double re;
        double im;
        public override string ToString() => $"{re} + ({im})i";
    }
}
