﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proj3
{
    class Rational
    {
        int denomenator;
        public Rational(int num, int denom)
        {
            Numerator = num;
            Denomenator = denom;
        }
        public int Numerator { get; set; }
        public int Denomenator
        {
            get { return denomenator; }
            set
            {
                try
                {
                    if(value == 0)
                        throw new System.ArgumentException("Знаменатель не может быть равен 0");
                    else
                        denomenator = value;
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine($"Ошибка: {e.Message}");
                }
            }
        }
        public static Rational operator +(Rational x, Rational y)
        {
            Rational num = new Rational(x.Denomenator, y.Denomenator);
            int new_denom = num.LSM();
            int new_numerator = ((new_denom / x.Denomenator) * x.Numerator) + ((new_denom / y.Denomenator) * y.Numerator);
            return new Rational(new_numerator, new_denom);
        }
        public static Rational operator -(Rational x, Rational y)
        {
            Rational num = new Rational(x.Denomenator, y.Denomenator);
            int new_denom = num.LSM();
            int new_numerator = ((new_denom / x.Denomenator) * x.Numerator) - ((new_denom / y.Denomenator) * y.Numerator);
            return new Rational(new_numerator, new_denom);
        }
        public static Rational operator *(Rational x, Rational y) => new Rational(x.Numerator * y.Numerator, x.Denomenator * y.Denomenator);
        public static Rational operator /(Rational x, Rational y) => new Rational(x.Numerator * y.Denomenator, x.Denomenator * y.Numerator);
        public override string ToString() 
        {
            if((Numerator < 0 && Denomenator > 0) || (Numerator > 0 && Denomenator < 0))
                return $"-({Math.Abs(Numerator) / GSD()}/{Math.Abs(Denomenator) / GSD()})"; 
            else
                return $"{Math.Abs(Numerator) / GSD()}/{Math.Abs(Denomenator) / GSD()}";
        }
        public int GSD() // НОД
        {
            int gsd = 0;
            if (Numerator == 0)
                return Math.Abs(Denomenator);
            if (Denomenator == 0)
                return Math.Abs(Numerator);
            for (int i = 1; i <= Math.Abs(Denomenator); i++)
                if (Math.Abs(Numerator) % i == 0 && Math.Abs(Denomenator) % i == 0)
                    gsd = i;
            return gsd;
        }
        public int LSM() // НОК
        {
            if (GSD() == 0)
                return 0;
            else
                return Math.Abs(Numerator * Denomenator) / GSD();
        }

    }
}
