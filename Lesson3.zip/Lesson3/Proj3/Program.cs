﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace Proj3
{
    /*Задание:  *Описать класс дробей - рациональных чисел, являющихся отношением двух целых чисел. 
                Предусмотреть методы сложения, вычитания, умножения и деления дробей. 
                Написать программу, демонстрирующую все разработанные элементы класса.
                ** Добавить проверку, чтобы знаменатель не равнялся 0. Выбрасывать исключение
                ArgumentException("Знаменатель не может быть равен 0"); Добавить упрощение дробей.

    Фамилия:    Орлов
*/
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Рациональные числа";
            try
            {
                Rational number1 = new Rational(3, 4);
                Rational number2 = new Rational(-4, 3);
                Console.WriteLine($"Вычитание:\t {number1} - {number2} = {number1 - number2}");
                Console.WriteLine($"Сложение:\t {number1} + {number2} = {number1 + number2}");
                Console.WriteLine($"Умножение:\t {number1} * {number2} = {number1 * number2}");
                Console.WriteLine($"Деление:\t {number1} / {number2} = {number1 / number2}");
                Console.ReadKey(true);
            }
            catch (System.DivideByZeroException e)
            {
                Console.WriteLine($"Ошибка: {e.Message}");
            }
            Console.ReadKey(true);

        }

    }
}
